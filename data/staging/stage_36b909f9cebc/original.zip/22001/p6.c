#include <stdio.h>

int main() {
    long long n;
    if (scanf("%lld", &n) == 1) {
        long long sum = 0;
        while (n > 0) {
            sum += (n % 10);
            n /= 10;
        }
        printf("%lld", sum);
    }
    return 0;
}
