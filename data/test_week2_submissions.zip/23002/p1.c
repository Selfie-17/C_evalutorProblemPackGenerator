#include <stdio.h>
int main() {
    printf("Syntax Error")
    return 0;
}